# Currency
[![Build Status](https://travis-ci.org/bartfeenstra/drupal-currency.svg?branch=8.x-3.x)](https://travis-ci.org/bartfeenstra/drupal-currency)

## About
This module provides your website with currency conversion, currency 
information & metadata, and amount/price display functionality.

In addition to this README file, also see PLUGINS.md.

## Installation
Currency has dependencies that must be [installed through Composer](https://www.drupal.org/node/2627292).
